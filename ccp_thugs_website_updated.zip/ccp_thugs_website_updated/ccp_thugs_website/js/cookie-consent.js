// Cookie Consent Script
document.addEventListener('DOMContentLoaded', function() {
    // Check if user has already accepted cookies
    const cookieConsent = document.getElementById('cookieConsent');
    const acceptCookiesBtn = document.getElementById('acceptCookies');
    const cookieSettingsBtn = document.getElementById('cookieSettings');
    
    // Show cookie consent banner if not previously accepted
    if (!localStorage.getItem('cookiesAccepted')) {
        setTimeout(function() {
            cookieConsent.classList.add('show');
        }, 1000);
    }
    
    // Handle accept cookies button
    if (acceptCookiesBtn) {
        acceptCookiesBtn.addEventListener('click', function() {
            localStorage.setItem('cookiesAccepted', 'true');
            cookieConsent.classList.remove('show');
        });
    }
    
    // Handle cookie settings button
    if (cookieSettingsBtn) {
        cookieSettingsBtn.addEventListener('click', function() {
            // Could open a modal with more detailed cookie settings
            alert('Cookie settings would be displayed here in a production environment.');
            localStorage.setItem('cookiesAccepted', 'true');
            cookieConsent.classList.remove('show');
        });
    }
});
