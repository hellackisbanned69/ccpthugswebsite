// Main JavaScript file for CCP THUGS website

document.addEventListener('DOMContentLoaded', function() {
    // Loading animation
    const loaderContainer = document.querySelector('.loader-container');
    
    if (loaderContainer) {
        window.addEventListener('load', function() {
            setTimeout(function() {
                loaderContainer.style.opacity = '0';
                setTimeout(function() {
                    loaderContainer.style.display = 'none';
                }, 500);
            }, 1000);
        });
    }

    // Mobile menu toggle
    const mobileMenuToggle = document.querySelector('.mobile-menu-toggle');
    const navLinks = document.querySelector('.nav-links');
    
    if (mobileMenuToggle && navLinks) {
        mobileMenuToggle.addEventListener('click', function() {
            navLinks.classList.toggle('active');
            mobileMenuToggle.classList.toggle('active');
        });
    }



    // Smooth scrolling for navigation links
    const smoothScrollLinks = document.querySelectorAll('a[href^="#"]');
    
    smoothScrollLinks.forEach(link => {
        link.addEventListener('click', function(e) {
            e.preventDefault();
            
            const targetId = this.getAttribute('href');
            if (targetId === '#') return;
            
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                window.scrollTo({
                    top: targetElement.offsetTop - 80,
                    behavior: 'smooth'
                });
                
                // Close mobile menu if open
                if (navLinks && navLinks.classList.contains('active')) {
                    navLinks.classList.remove('active');
                    mobileMenuToggle.classList.remove('active');
                }
            }
        });
    });

    // Navigation indicator for current section
    const sections = document.querySelectorAll('section[id]');
    const navIndicator = document.createElement('div');
    navIndicator.className = 'nav-indicator';
    
    if (document.querySelector('.nav-links')) {
        document.querySelector('.nav-links').appendChild(navIndicator);
    }
    
    function updateNavIndicator() {
        let currentSection = '';
        let currentLink = null;
        
        sections.forEach(section => {
            const sectionTop = section.offsetTop;
            const sectionHeight = section.offsetHeight;
            
            if (window.scrollY >= sectionTop - 200 && window.scrollY < sectionTop + sectionHeight - 200) {
                currentSection = section.getAttribute('id');
            }
        });
        
        if (currentSection) {
            const newCurrentLink = document.querySelector(`.nav-links a[href="#${currentSection}"]`);
            
            if (newCurrentLink && newCurrentLink !== currentLink) {
                currentLink = newCurrentLink;
                
                const linkRect = currentLink.getBoundingClientRect();
                const navRect = document.querySelector('.nav-links').getBoundingClientRect();
                
                navIndicator.style.width = `${linkRect.width}px`;
                navIndicator.style.left = `${linkRect.left - navRect.left}px`;
                navIndicator.style.opacity = '1';
            }
        } else {
            navIndicator.style.opacity = '0';
        }
    }
    
    window.addEventListener('scroll', updateNavIndicator);
    window.addEventListener('resize', updateNavIndicator);
    
    // Initial update
    setTimeout(updateNavIndicator, 100);
});
